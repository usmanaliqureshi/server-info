<?php

	defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

	include_once PLUGIN_DIR . 'classes/classes.php';

	include_once PLUGIN_DIR . 'actions/actions.php';
	
?>